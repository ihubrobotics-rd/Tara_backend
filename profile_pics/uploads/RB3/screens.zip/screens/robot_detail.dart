import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class RobotDetailPage extends StatefulWidget {
  final String roboId;

  const RobotDetailPage({
    Key? key,
    required this.roboId,
  }) : super(key: key);

  @override
  _RobotDetailPageState createState() => _RobotDetailPageState();
}

class _RobotDetailPageState extends State<RobotDetailPage> {
  bool _isLoading = true;
  Map<String, dynamic> _robotDetail = {};
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchRobotDetails();
  }

  Future<void> _fetchRobotDetails() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      final response = await http.get(
        Uri.parse('https://anumolm403.pythonanywhere.com/robot/robot/detail/${widget.roboId}/'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _robotDetail = data['data'];
          _isLoading = false;
        });
      } else {
        setState(() {
          _error = 'Failed to load robot details. Status: ${response.statusCode}';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'Error: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Robot Details'),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(_error!, style: const TextStyle(color: Colors.red)),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _fetchRobotDetails,
                        child: const Text('Retry'),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: _fetchRobotDetails,
                  child: SingleChildScrollView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    padding: const EdgeInsets.all(16.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          _robotDetail['robo_name'] ?? 'No Name',
                          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        const SizedBox(height: 16),
                        _buildDetailRow('Robot ID', _robotDetail['robo_id']?.toString() ?? 'N/A'),
                        _buildDetailRow('Battery Status', _robotDetail['battery_status']?.toString() ?? 'Unknown'),
                        _buildDetailRow('Working Time', _robotDetail['working_time']?.toString() ?? 'Unknown'),
                        _buildDetailRow('Position', _robotDetail['position']?.toString() ?? 'Unknown'),
                        _buildDetailRow('Subscription', _robotDetail['subscription']?.toString() ?? 'No'),
                        _buildDetailRow('Language', _robotDetail['language']?.toString() ?? 'Unknown'),
                      ],
                    ),
                  ),
                ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: Theme.of(context).textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }
}
