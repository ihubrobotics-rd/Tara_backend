import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'profile_page.dart';
import 'robot_detail.dart'; // Import the RobotDetailPage

class AdminDashboard extends StatefulWidget {
  @override
  _AdminDashboardState createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  bool _isLoading = false;
  Map<String, dynamic> _robotData = {};
  String? _profilePicUrl; // Store the profile picture URL

  @override
  void initState() {
    super.initState();
    _fetchRobotsData();
    _fetchUserProfile(); // Fetch the user profile data
  }

  // Fetch user profile details using the stored user ID
  Future<void> _fetchUserProfile() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    int? userId = prefs.getInt('user_id'); // Get the user ID from shared preferences

    if (userId != null) {
      setState(() {
        _isLoading = true;
      });

      try {
        final response = await http.get(
          Uri.parse(
              'https://anumolm403.pythonanywhere.com/accounts/admin/detail/$userId/'),
        );

        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          setState(() {
            _profilePicUrl =
                data['data']['profile_pic']; // Set the profile picture URL
          });
        } else {
          print('Failed to load user profile data');
        }
      } catch (e) {
        print('Error fetching user profile: $e');
      } finally {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  Future<void> _fetchRobotsData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      final response = await http.get(
        Uri.parse('https://anumolm403.pythonanywhere.com/robot/list/robots/'),
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        setState(() {
          _robotData = data['data'];
        });
      } else {
        print('Failed to load robot data');
      }
    } catch (e) {
      print('Error fetching robot data: $e');
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  void _logout() {
    print("Logged out");
  }

  void _goToProfile() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => ProfilePage()),
    );
  }

  // Add the method to navigate to the RobotDetails page
  void _goToRobotDetails(String roboId) {
    print('Navigating to Robot Detail for ID: $roboId'); // Debug print
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => RobotDetailPage(roboId: roboId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Admin Dashboard'),
        actions: [
          // Profile Picture Button
          IconButton(
            icon: CircleAvatar(
              backgroundImage: _profilePicUrl != null
                  ? NetworkImage(_profilePicUrl!) // Show profile image if available
                  : AssetImage('assets/default_profile.png'), // Default image if null
            ),
            onPressed: _goToProfile,
          ),
          // Logout Button
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: _logout,
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            ListTile(
              title: Text('Language'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Robots'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Users'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Sale Robots'),
              onTap: () {},
            ),
          ],
        ),
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16.0,
                  mainAxisSpacing: 16.0,
                ),
                itemCount: _robotData.length,
                itemBuilder: (context, index) {
                  String roboId = _robotData.keys.elementAt(index);
                  var robot = _robotData[roboId];

                  return Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(
                            robot['robo_name'],
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text('ID: ${robot['robo_id']}'),
                        ),
                        Spacer(),
                        ElevatedButton(
                          onPressed: () {
                            String roboId = robot['robo_id']; // Get the robo_id from the data
                            // Debug print
                            _goToRobotDetails(roboId); // Navigate to the robot details page
                          },
                          child: Text('View'),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
    );
  }
}
